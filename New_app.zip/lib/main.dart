import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'My app',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.blue),
      home: profileCardScreen(),
    );
  }
}

class profileCardScreen extends StatelessWidget {
  const profileCardScreen({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: const Color.fromARGB(255, 114, 192, 255),
        appBar: AppBar(
          title: const Text('Profile Card'),
          backgroundColor: Colors.blueAccent,
        ),
        body: Center(child: body_tarjeta()));
  }
}

class body_tarjeta extends StatelessWidget {
  const body_tarjeta({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
        margin: EdgeInsets.all(20),
        child: Card(
            elevation: 8,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
                padding: EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    //foto de perfil
                    CircleAvatar(
                      backgroundImage: NetworkImage(
                          'https://www.fayerwayer.com/resizer/v2/3DXKCTCZABBDJHWQIR4G45EMXM.jpg?auth=c70eba8d7357363af4862b2f2498aa9ea2804e7984aa1d66b8c6d26f69c2c45f&width=800&height=800'),
                      radius: 50,

                      // child: Icon(
                      //   Icons.person,
                      //   size: 60,
                      //   color: Colors.black45,
                      // ),
                    ),
                    SizedBox(
                      height: 20,
                    ),

                    //nombre
                    Text(
                      'Freider',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(
                      height: 8,
                    ),

                    //email
                    Text(
                      'Email',
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.black),
                    ),
                    SizedBox(
                      height: 8,
                    ),

                    Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          ElevatedButton.icon(
                            onPressed: () {
                              //metodo algo
                              _motrarMensaje(
                                  context, 'Llamando a Freider', Colors.green);
                            },
                            icon: Icon(Icons.phone_android_outlined),
                            label: Text('Llamar'),
                            style: ElevatedButton.styleFrom(
                              disabledBackgroundColor: Colors.black,
                              foregroundColor: Colors.black,
                            ),
                          ),
                          ElevatedButton.icon(
                            onPressed: () {
                              //metodo algo
                              _enviarMensaje(
                                  context, 'Enviando mensaje a Freider');
                            },
                            icon: Icon(Icons.message_outlined),
                            label: Text('Mensaje'),
                            style: ElevatedButton.styleFrom(
                              disabledBackgroundColor: Colors.black,
                              foregroundColor: Colors.black,
                            ),
                          )
                        ]),
                    SizedBox(height: 15),

                    SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed: () {
                            //METODO ALGO
                            _editarPerfil(
                                context, 'Editando perfil de Freider');
                          },
                          icon: Icon(Icons.edit),
                          label: Text('Editar Perfil'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.orange,
                            foregroundColor: Colors.white,
                          ),
                        ))
                  ],
                ))));
  }

  void _motrarMensaje(BuildContext context, String mensaje, Color color2) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          mensaje,
          style: TextStyle(color: Colors.black),
        ),
        duration: Duration(seconds: 2),
        backgroundColor: color2,
      ),
    );
  }

  void _enviarMensaje(BuildContext context, String mensaje) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(mensaje),
        duration: Duration(seconds: 2),
        backgroundColor: Colors.redAccent,
      ),
    );
  }

  void _editarPerfil(BuildContext context, String mensaje) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(mensaje),
        duration: Duration(seconds: 2),
        backgroundColor: Colors.redAccent,
      ),
    );
  }
}
